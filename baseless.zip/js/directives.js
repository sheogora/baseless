//app.directive('sampleDirective', function () {
//    return {
//        restrict: 'E',
//        scope: false,
//        link: function (scope, element, attrs) {
//        }
//    };
//});