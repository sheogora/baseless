app.controller("NavCtrl", function ($scope, $route) {
});

app.controller("Proj1Ctrl", function ($scope, $http) {
	
});